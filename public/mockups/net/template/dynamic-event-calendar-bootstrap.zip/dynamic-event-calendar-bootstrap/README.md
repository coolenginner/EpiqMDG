# bootstrap-4-calendar
A nicely designed bootstrap 4 calendar

![screenshot](https://github.com/ylli2000/bootstrap-4-calendar/blob/master/screenshot.PNG "screenshot")
